export default function Navegacao(){
    return(
        <nav>
            <ul>
                <li>
                    <a href="/">Index</a>
                    <a href="/home">Index</a>
                </li>
            </ul>
        </nav>
    )
}