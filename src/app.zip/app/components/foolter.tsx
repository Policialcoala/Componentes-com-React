export default function Rodape(){
    return(
        <div className="rodape">
            <p>&copy; 2022 Copyright:

                <a className="text-white" href="https://github.com/Policialcoala
                ">
                    Heitor Schornak
                </a>
            </p>
            </div>
    )
}