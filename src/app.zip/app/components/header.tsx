export default function Header(){
    return(
        <header>
            <h1>
                JUCACO
                </h1>
        </header>
    );
}
